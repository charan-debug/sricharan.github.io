# Resume Website - GitHub Pages Deployment

This repository contains the files for a personal resume website designed to be hosted on GitHub Pages.

## Website Features

- Professional black and white theme
- Custom mouse cursor effects
- Interactive hover animations
- Responsive design for all devices
- Company and institution logos integration

## How to Use

1. Fork or clone this repository
2. Customize the content in `index.html` to match your information
3. Replace logos in the `images/logos` directory with your own
4. Enable GitHub Pages in repository settings
5. Your site will be available at `https://yourusername.github.io/repository-name`

## File Structure

- `index.html` - Main HTML file
- `css/style.css` - Styling for the website
- `js/main.js` - JavaScript for animations and interactivity
- `images/` - Directory containing images and logos
- `.nojekyll` - File to prevent GitHub Pages from using Jekyll processing

## Customization

To customize this website:

1. Edit the HTML content in `index.html`
2. Modify styles in `css/style.css`
3. Adjust animations and interactions in `js/main.js`
4. Replace images in the `images` directory

## Credits

- Font Awesome for icons
- Google Fonts for typography
