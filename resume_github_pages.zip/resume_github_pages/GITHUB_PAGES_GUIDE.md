# GitHub Pages Deployment Guide

This document provides step-by-step instructions for deploying your resume website to GitHub Pages.

## Step 1: Create a GitHub Repository

1. Go to [GitHub](https://github.com) and sign in to your account (or create one if you don't have it)
2. Click on the "+" icon in the top-right corner and select "New repository"
3. Name your repository: `yourusername.github.io` (replace "yourusername" with your actual GitHub username)
   - **Note**: If you use this exact format, your site will be available at `https://yourusername.github.io`
   - Alternatively, you can use any name (e.g., `resume-website`) and your site will be available at `https://yourusername.github.io/resume-website`
4. Make sure the repository is set to "Public"
5. Check the box to "Add a README file"
6. Click "Create repository"

## Step 2: Upload Your Website Files

### Option 1: Upload via GitHub Web Interface

1. In your new repository, click on "Add file" and select "Upload files"
2. Drag and drop all the files and folders from the ZIP file you downloaded
3. Make sure to include the `.nojekyll` file (it might be hidden in your file explorer)
4. Click "Commit changes"

### Option 2: Upload via Git Command Line (Advanced)

1. Install Git on your computer if you haven't already
2. Extract the ZIP file to a folder on your computer
3. Open a terminal/command prompt in that folder
4. Run the following commands:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/yourusername/your-repository-name.git
git push -u origin main
```

## Step 3: Enable GitHub Pages

1. Go to your repository on GitHub
2. Click on "Settings" (tab with gear icon)
3. Scroll down to the "GitHub Pages" section (or click on "Pages" in the left sidebar)
4. Under "Source", select "Deploy from a branch"
5. Select "main" branch and "/ (root)" folder
6. Click "Save"
7. Wait a few minutes for GitHub to build and deploy your site

## Step 4: Access Your Website

- If you named your repository `yourusername.github.io`, your website will be available at `https://yourusername.github.io`
- If you used a different name, your website will be available at `https://yourusername.github.io/repository-name`

## Troubleshooting

1. **Files not showing up**: Make sure you uploaded all files including the hidden `.nojekyll` file
2. **CSS or JavaScript not loading**: Check that file paths in your HTML are correct
3. **Page not found**: It may take a few minutes for GitHub Pages to deploy your site
4. **Custom domain**: You can set up a custom domain in the GitHub Pages settings

## Updating Your Website

To update your website after making changes:

1. Make your changes locally
2. Upload the modified files using the same method you used initially
3. GitHub Pages will automatically update your site within a few minutes
